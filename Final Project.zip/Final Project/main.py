import speech_recognition as sr
from gtts import gTTS
import pygame
import ollama  # Assumes ollama model is set up and authenticated

# Initialize the recognizer
recognizer = sr.Recognizer()

# Function to convert speech to text
def speech_to_text():
    with sr.Microphone() as source:
        print("Please speak into the microphone...")
        recognizer.adjust_for_ambient_noise(source, duration=1)
        audio = recognizer.listen(source)
        try:
            text = recognizer.recognize_google(audio)
            print("You said:", text)
            return text
        except sr.UnknownValueError:
            print("Sorry, I could not understand the audio.")
            return None
        except sr.RequestError:
            print("Could not request results from the speech recognition service.")
            return None

# Function to get LLM response
def get_llm_response(prompt):
    try:
        response = ollama.chat(model="meditron:7b", messages=[{"role": "user", "content": prompt}])
        return response['message']['content']
    except Exception as e:
        print("Error in LLM response:", e)
        return "I'm sorry, I couldn't process that."

# Function to convert text to speech and play it
def text_to_speech(text):
    tts = gTTS(text=text, lang='en')
    tts.save("response.mp3")
    pygame.mixer.init()
    pygame.mixer.music.load("response.mp3")
    pygame.mixer.music.play()
    while pygame.mixer.music.get_busy():  # Wait until playback is finished
        continue

# Main interaction loop
def interactive_voice_assistant():
    user_input = speech_to_text()
    if user_input:
        response = get_llm_response(user_input)
        print("Assistant:", response)
        text_to_speech(response)

# Run the assistant
if __name__ == "__main__":
    interactive_voice_assistant()
